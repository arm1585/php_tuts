<?php
require_once 'header.php'
?>

<main>
<?php
// --- MAIN EXAMPLE CODE START ---

$stds_to_marks = array(
    // Ranges of marks are in 1..20 not the standard 60 to 95.
    'David' => 10, 'Eva' => 17, 'Mike' => 3, 'Jack' => 20, 'Marta' => 13, 'Bob' => 15
);

echo "<table>";
echo "<tr><th>Student</td><th>Mark</th><th>Status</th></tr>";

foreach ($stds_to_marks as $std => $mark) {
    if ($mark < 10) {
        $status_image = "cry.png";
    } elseif ($mark >= 10 && $mark <= 14) {
        $status_image = "sad.png";
    } elseif ($mark > 14 && $mark <= 17) {
        $status_image = "happy1.png";
    } elseif ($mark > 17 && $mark <= 20) {
        $status_image = "happy2.png";
    } else {
        $status_image = "error.png";
    }

    echo "<tr>";
    echo "<td>$std</td>";
    echo "<td>$mark</td>";
    echo "<td><img src=\"images/$status_image\"></td>";
    echo "</tr>";
}

echo "</table>";
// --- MAIN EXAMPLE CODE END   ---

?>

</main>

<?php
require_once 'footer.php';

