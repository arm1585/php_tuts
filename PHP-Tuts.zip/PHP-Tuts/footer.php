    <footer>
        <a href="index.php">Back to the example browser...</a>
    </footer>
</body>
</html>