<?php
// Header of the example browser
require_once 'header.php';
?>
<?php

$examples = array(
    array("title" => "Array Example #1", "src" => "array_ex_1.php", "desc" => "An example of arrays, loops and tables. shows student names and their marks."),
    array("title" => "Array Example #2", "src" => "wheather.php", "desc" => "An example of arrays, loops and tables. shows days of a week and the weather."),
);

?>

<main>
    <?php foreach ($examples as $example): ?>
        <a href=<?= $example['src'] ?> class="example-link"><?= $example['title'] ?> - </a> <?= $example['desc'] ?> <br>
    <?php endforeach ?>
</main>

<?php
// footer of example browser
require_once 'footer.php';