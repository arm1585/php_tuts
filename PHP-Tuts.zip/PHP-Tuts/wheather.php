<?php
require_once 'header.php';
?>

<?php
// --- MAIN EXAMPLE CODE START ---

$days_of_week = array(
    "Sat" => 20,
    "Sun" => 22,
    "Mon" => 12,
    "Tue" => 7,
    "Wed" => 11,
    "Fri" => 25
);

// --- MAIN EXAMPLE CODE END   ---
?>

<main>
<table>
    <tr>
        <?php foreach ($days_of_week as $day => $temp): ?>
            <th colspan="2"><?= $day ?></th>
        <?php endforeach; ?>
    </tr>
    <tr>
        <?php foreach ($days_of_week as $day => $temp): ?>
            <td><?= $temp ?></td>
            <td>
               <?php
                if ($temp < 10) {
                    $temp_image = "snowy.png";
                } elseif ($temp >= 10 && $temp <= 12) {
                    $temp_image = "rainy.png";
                } elseif ($temp > 12 && $temp <= 15) {
                    $temp_image = "cloudy.png";
                } elseif ($temp > 15 && $temp <= 20) {
                    $temp_image = "mid-cloudy.png";
                } else {
                    $temp_image = "sunny.png";
                }
               ?> 
               <img src="<?= "images/" . $temp_image ?>" alt="">
            </td>
        <?php endforeach; ?>
    </tr>
</table>
</main>

<?php
require_once 'footer.php';